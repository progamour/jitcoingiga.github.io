# Minecraft-Autoclicker
Basic minecraft autoclicker for beginners. Will update stuff later on if I feel like it.

Questions?
Join -> https://discord.gg/DhE6nuWGta

![WSLBsZJoXz](https://user-images.githubusercontent.com/71045814/173140909-86cd861f-74f5-4de2-9371-be6798deb016.png)
