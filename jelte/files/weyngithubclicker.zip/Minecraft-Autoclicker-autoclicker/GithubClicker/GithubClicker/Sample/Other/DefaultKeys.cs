﻿namespace GithubClicker.Sample.Other
{
    public class DefaultKeys
    {
        public static int keyS1 = 49; // D1
        public static int keyS2 = 50; // D2
        public static int keyS3 = 51; // D3
        public static int keyS4 = 52; // D4 
        public static int keyS5 = 53; // D5
        public static int keyS6 = 54; // D6 
        public static int keyS7 = 55; // D7
        public static int keyS8 = 56; // D8 
        public static int keyS9 = 57; // D9
    }
}
