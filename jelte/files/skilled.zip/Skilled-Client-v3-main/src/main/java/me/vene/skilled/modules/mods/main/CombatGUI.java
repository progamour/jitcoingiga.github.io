 package me.vene.skilled.modules.mods.main;
 
 import me.vene.skilled.modules.Category;
 import me.vene.skilled.modules.Module;
 
public class CombatGUI extends Module
{
    public CombatGUI() {
        super("Combat", 0, Category.G);
    }
}
