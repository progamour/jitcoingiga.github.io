package me.vene.skilled.modules.mods.main;
 
 import me.vene.skilled.modules.Category;
 import me.vene.skilled.modules.Module;

public class RenderGUI extends Module
{
    public RenderGUI() {
        super("Render", 0, Category.G);
    }
}
