 package me.vene.skilled.modules.mods.main;

 import me.vene.skilled.modules.Category;
 import me.vene.skilled.modules.Module;
 
public class PlayerGUI extends Module
{
    public PlayerGUI() {
        super("Player", 0, Category.G);
    }
}
