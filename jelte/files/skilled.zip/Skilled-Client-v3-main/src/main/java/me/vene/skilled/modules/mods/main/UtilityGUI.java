package me.vene.skilled.modules.mods.main;

 import me.vene.skilled.modules.Category;
 import me.vene.skilled.modules.Module;

public class UtilityGUI extends Module
{
    public UtilityGUI() {
        super("Utility", 0, Category.G);
    }
}
