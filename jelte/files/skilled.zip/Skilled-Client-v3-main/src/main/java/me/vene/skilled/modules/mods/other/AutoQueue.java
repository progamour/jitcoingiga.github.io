 package me.vene.skilled.modules.mods.other;
 
 import me.vene.skilled.modules.Category;
 import me.vene.skilled.modules.Module;
 import me.vene.skilled.utilities.StringRegistry;
 
public class AutoQueue extends Module
{
    public AutoQueue() {
        super(StringRegistry.register("Auto Queue"), 0, Category.O);
    }
}
