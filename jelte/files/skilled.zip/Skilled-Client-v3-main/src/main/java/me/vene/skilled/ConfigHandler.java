package me.vene.skilled;

public class ConfigHandler {
	
}
