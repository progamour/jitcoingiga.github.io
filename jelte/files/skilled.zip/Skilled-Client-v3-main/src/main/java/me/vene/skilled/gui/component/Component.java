 package me.vene.skilled.gui.component;

public class Component
{
    public void render() {
    }
    
    public void keyTyped(final char typedChar, final int key) {
    }
    
    public void updateComponent(final int mouseX, final int mouseY) {
    }
    
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
    }
    
    public void setOff(final int newOff) {
    }
    
    public int getHeight() {
        return 0;
    }
}
