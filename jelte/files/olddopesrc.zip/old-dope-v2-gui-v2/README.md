# old-dope-v2
# A developer I had the misfortune to work with decided to release a messed up and unworked version of dope v2, so I decided to leak the sources for my own project. # THIS VERSION HAS NOTHING TO DO WITH THE REAL V2 OF DOPE, THANKS FOR TAKING IT INTO CONSIDERATION
