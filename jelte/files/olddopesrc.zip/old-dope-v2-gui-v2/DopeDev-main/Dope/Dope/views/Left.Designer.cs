﻿
namespace Dope.views
{
    partial class Left
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RightSwitch = new Dope.Theme.button();
            this.S9 = new Dope.Theme.Slots();
            this.S8 = new Dope.Theme.Slots();
            this.S7 = new Dope.Theme.Slots();
            this.S6 = new Dope.Theme.Slots();
            this.S5 = new Dope.Theme.Slots();
            this.S4 = new Dope.Theme.Slots();
            this.S3 = new Dope.Theme.Slots();
            this.S2 = new Dope.Theme.Slots();
            this.S1 = new Dope.Theme.Slots();
            this.checkbox5 = new Dope.Theme.Checkbox();
            this.checkbox4 = new Dope.Theme.Checkbox();
            this.checkbox3 = new Dope.Theme.Checkbox();
            this.LeftBind = new Dope.Theme.Bind();
            this.checkbox2 = new Dope.Theme.Checkbox();
            this.checkbox1 = new Dope.Theme.Checkbox();
            this.LeftMin = new Dope.Theme.Slider();
            this.LeftMax = new Dope.Theme.Slider();
            this.LeftToggle = new Dope.Theme.Switch();
            this.SuspendLayout();
            // 
            // RightSwitch
            // 
            this.RightSwitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RightSwitch.Collapse = false;
            this.RightSwitch.CollapseWidth = 0;
            this.RightSwitch.Image = null;
            this.RightSwitch.Location = new System.Drawing.Point(430, 375);
            this.RightSwitch.Name = "RightSwitch";
            this.RightSwitch.Size = new System.Drawing.Size(34, 36);
            this.RightSwitch.TabIndex = 18;
            this.RightSwitch.Text = ">";
            this.RightSwitch.Click += new System.EventHandler(this.RightSwitch_Click);
            // 
            // S9
            // 
            this.S9.Checked = false;
            this.S9.Key = 0;
            this.S9.Location = new System.Drawing.Point(253, 215);
            this.S9.Name = "S9";
            this.S9.Size = new System.Drawing.Size(23, 23);
            this.S9.TabIndex = 17;
            this.S9.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S9.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S8
            // 
            this.S8.Checked = false;
            this.S8.Key = 0;
            this.S8.Location = new System.Drawing.Point(224, 215);
            this.S8.Name = "S8";
            this.S8.Size = new System.Drawing.Size(23, 23);
            this.S8.TabIndex = 16;
            this.S8.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S8.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S7
            // 
            this.S7.Checked = false;
            this.S7.Key = 0;
            this.S7.Location = new System.Drawing.Point(195, 215);
            this.S7.Name = "S7";
            this.S7.Size = new System.Drawing.Size(23, 23);
            this.S7.TabIndex = 15;
            this.S7.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S7.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S6
            // 
            this.S6.Checked = false;
            this.S6.Key = 0;
            this.S6.Location = new System.Drawing.Point(166, 215);
            this.S6.Name = "S6";
            this.S6.Size = new System.Drawing.Size(23, 23);
            this.S6.TabIndex = 14;
            this.S6.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S6.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S5
            // 
            this.S5.Checked = false;
            this.S5.Key = 0;
            this.S5.Location = new System.Drawing.Point(137, 215);
            this.S5.Name = "S5";
            this.S5.Size = new System.Drawing.Size(23, 23);
            this.S5.TabIndex = 13;
            this.S5.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S5.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S4
            // 
            this.S4.Checked = false;
            this.S4.Key = 0;
            this.S4.Location = new System.Drawing.Point(108, 215);
            this.S4.Name = "S4";
            this.S4.Size = new System.Drawing.Size(23, 23);
            this.S4.TabIndex = 12;
            this.S4.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S4.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S3
            // 
            this.S3.Checked = false;
            this.S3.Key = 0;
            this.S3.Location = new System.Drawing.Point(79, 215);
            this.S3.Name = "S3";
            this.S3.Size = new System.Drawing.Size(23, 23);
            this.S3.TabIndex = 11;
            this.S3.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S3.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S2
            // 
            this.S2.Checked = false;
            this.S2.Key = 0;
            this.S2.Location = new System.Drawing.Point(50, 215);
            this.S2.Name = "S2";
            this.S2.Size = new System.Drawing.Size(23, 23);
            this.S2.TabIndex = 10;
            this.S2.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S2.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // S1
            // 
            this.S1.Checked = false;
            this.S1.Key = 0;
            this.S1.Location = new System.Drawing.Point(21, 215);
            this.S1.Name = "S1";
            this.S1.Size = new System.Drawing.Size(23, 23);
            this.S1.TabIndex = 9;
            this.S1.CheckChange += new System.EventHandler(this.SlotsBoolChange);
            this.S1.KeyChange += new System.EventHandler(this.SlotsKeyChange);
            // 
            // checkbox5
            // 
            this.checkbox5.Checked = false;
            this.checkbox5.Location = new System.Drawing.Point(21, 154);
            this.checkbox5.Name = "checkbox5";
            this.checkbox5.Size = new System.Drawing.Size(168, 45);
            this.checkbox5.TabIndex = 8;
            this.checkbox5.Text = "Slots";
            this.checkbox5.Click += new System.EventHandler(this.checkbox5_Click);
            // 
            // checkbox4
            // 
            this.checkbox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkbox4.Checked = true;
            this.checkbox4.Location = new System.Drawing.Point(310, 205);
            this.checkbox4.Name = "checkbox4";
            this.checkbox4.Size = new System.Drawing.Size(145, 45);
            this.checkbox4.TabIndex = 7;
            this.checkbox4.Text = "Focus MC";
            this.checkbox4.Click += new System.EventHandler(this.checkbox4_Click);
            // 
            // checkbox3
            // 
            this.checkbox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkbox3.Checked = false;
            this.checkbox3.Location = new System.Drawing.Point(310, 154);
            this.checkbox3.Name = "checkbox3";
            this.checkbox3.Size = new System.Drawing.Size(145, 45);
            this.checkbox3.TabIndex = 6;
            this.checkbox3.Text = "Break Blocks";
            this.checkbox3.Click += new System.EventHandler(this.checkbox3_Click);
            // 
            // LeftBind
            // 
            this.LeftBind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LeftBind.AutoSize = true;
            this.LeftBind.Key = 0;
            this.LeftBind.Location = new System.Drawing.Point(306, 19);
            this.LeftBind.Name = "LeftBind";
            this.LeftBind.Size = new System.Drawing.Size(55, 21);
            this.LeftBind.TabIndex = 5;
            this.LeftBind.Text = "[Bind]";
            this.LeftBind.TextChanged += new System.EventHandler(this.LeftBind_TextChanged);
            // 
            // checkbox2
            // 
            this.checkbox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkbox2.Checked = false;
            this.checkbox2.Location = new System.Drawing.Point(310, 103);
            this.checkbox2.Name = "checkbox2";
            this.checkbox2.Size = new System.Drawing.Size(145, 45);
            this.checkbox2.TabIndex = 4;
            this.checkbox2.Text = "IA Random";
            this.checkbox2.Click += new System.EventHandler(this.checkbox2_Click);
            // 
            // checkbox1
            // 
            this.checkbox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkbox1.Checked = true;
            this.checkbox1.Location = new System.Drawing.Point(310, 52);
            this.checkbox1.Name = "checkbox1";
            this.checkbox1.Size = new System.Drawing.Size(145, 45);
            this.checkbox1.TabIndex = 3;
            this.checkbox1.Text = "While playing";
            this.checkbox1.Click += new System.EventHandler(this.checkbox1_Click);
            // 
            // LeftMin
            // 
            this.LeftMin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LeftMin.Diviser = 10;
            this.LeftMin.Location = new System.Drawing.Point(12, 103);
            this.LeftMin.Maximum = 200;
            this.LeftMin.Minimum = 10;
            this.LeftMin.Name = "LeftMin";
            this.LeftMin.ShowValue = false;
            this.LeftMin.Size = new System.Drawing.Size(275, 45);
            this.LeftMin.TabIndex = 2;
            this.LeftMin.Text = "Min";
            this.LeftMin.Value = 90;
            this.LeftMin.Scroll += new Dope.Theme.Slider.ScrollEventHandler(this.LeftMin_Scroll);
            // 
            // LeftMax
            // 
            this.LeftMax.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LeftMax.Diviser = 10;
            this.LeftMax.Location = new System.Drawing.Point(12, 52);
            this.LeftMax.Maximum = 200;
            this.LeftMax.Minimum = 10;
            this.LeftMax.Name = "LeftMax";
            this.LeftMax.ShowValue = false;
            this.LeftMax.Size = new System.Drawing.Size(275, 45);
            this.LeftMax.TabIndex = 1;
            this.LeftMax.Text = "Max";
            this.LeftMax.Value = 130;
            this.LeftMax.Scroll += new Dope.Theme.Slider.ScrollEventHandler(this.LeftMax_Scroll);
            // 
            // LeftToggle
            // 
            this.LeftToggle.Checked = false;
            this.LeftToggle.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftToggle.Location = new System.Drawing.Point(12, 12);
            this.LeftToggle.Name = "LeftToggle";
            this.LeftToggle.Size = new System.Drawing.Size(158, 34);
            this.LeftToggle.TabIndex = 0;
            this.LeftToggle.Text = "Left";
            this.LeftToggle.Click += new System.EventHandler(this.switch1_Click);
            // 
            // Left
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(464, 411);
            this.Controls.Add(this.RightSwitch);
            this.Controls.Add(this.S9);
            this.Controls.Add(this.S8);
            this.Controls.Add(this.S7);
            this.Controls.Add(this.S6);
            this.Controls.Add(this.S5);
            this.Controls.Add(this.S4);
            this.Controls.Add(this.S3);
            this.Controls.Add(this.S2);
            this.Controls.Add(this.S1);
            this.Controls.Add(this.checkbox5);
            this.Controls.Add(this.checkbox4);
            this.Controls.Add(this.checkbox3);
            this.Controls.Add(this.LeftBind);
            this.Controls.Add(this.checkbox2);
            this.Controls.Add(this.checkbox1);
            this.Controls.Add(this.LeftMin);
            this.Controls.Add(this.LeftMax);
            this.Controls.Add(this.LeftToggle);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Left";
            this.Text = "AutoClicker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Theme.Switch LeftToggle;
        private Theme.Slider LeftMax;
        private Theme.Slider LeftMin;
        private Theme.Checkbox checkbox1;
        private Theme.Checkbox checkbox2;
        private Theme.Bind LeftBind;
        private Theme.Checkbox checkbox3;
        private Theme.Checkbox checkbox4;
        private Theme.Checkbox checkbox5;
        private Theme.Slots S1;
        private Theme.Slots S2;
        private Theme.Slots S3;
        private Theme.Slots S6;
        private Theme.Slots S5;
        private Theme.Slots S4;
        private Theme.Slots S9;
        private Theme.Slots S8;
        private Theme.Slots S7;
        private Theme.button RightSwitch;
    }
}