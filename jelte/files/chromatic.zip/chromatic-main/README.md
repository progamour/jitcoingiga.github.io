# chromatic
all of u dumbasses that swear up and down its a rat can go ahead and look for urself
everyone else enjoy
