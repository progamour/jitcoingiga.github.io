#include "ext/main.h"

int main() {
	ext::init();

	return 0;
}