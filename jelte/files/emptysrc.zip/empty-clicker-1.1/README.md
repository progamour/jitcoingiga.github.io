### Empty Clicker

- Made in Modern C++.
- Using minimal dependencies.

## Paid version

We have a paid version too. Check it out on [empty.wtf](https://www.empty.wtf/)

# Clicker Features

+ Left Clicker
+ Right Clicker
+ Bind System
+ Self Destruct
+ Hide Window