#pragma once

#include <Windows.h>
#include <memory>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <ostream>

#include <thread>
#include <chrono>

#include <jni.h>
#include <jvmti.h>

#include "xorstr.h"
#include "hook/hook.h"