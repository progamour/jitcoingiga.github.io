#pragma once

#include "../util/includes.h"

namespace hooks {

	bool wgl_swap_buffers(HDC hdc);

}