# Latemod
Open-source "Ghost" Client written in C++

# It say's C right there
Yeah libraries are a pain in the ass.
