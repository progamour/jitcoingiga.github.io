﻿Public Class Start

    <STAThread>
    Private Sub Main()
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New Main())
    End Sub
End Class
