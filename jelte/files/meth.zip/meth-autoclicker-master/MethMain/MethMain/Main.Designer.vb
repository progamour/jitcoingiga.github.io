﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Autoclicker = New System.Windows.Forms.Timer(Me.components)
        Me.WTap = New System.Windows.Forms.Timer(Me.components)
        Me.STap = New System.Windows.Forms.Timer(Me.components)
        Me.AutoPot = New System.Windows.Forms.Timer(Me.components)
        Me.AutoRod = New System.Windows.Forms.Timer(Me.components)
        Me.HideButton = New System.Windows.Forms.Timer(Me.components)
        Me.Bind = New System.Windows.Forms.Timer(Me.components)
        Me.CustomRainbow = New System.Windows.Forms.Timer(Me.components)
        Me.CustomColor = New System.Windows.Forms.Timer(Me.components)
        Me.Prefetch = New System.Windows.Forms.Timer(Me.components)
        Me.MainForm = New Meth.Theme()
        Me.ThirteenControlBox1 = New Meth.ThirteenControlBox()
        Me.FlatTabControl1 = New Meth.FlatTabControl()
        Me.MainTab = New System.Windows.Forms.TabPage()
        Me.FlatLabel41 = New Meth.FlatLabel()
        Me.FlatLabel40 = New Meth.FlatLabel()
        Me.FlatLabel39 = New Meth.FlatLabel()
        Me.FlatLabel38 = New Meth.FlatLabel()
        Me.FlatLabel37 = New Meth.FlatLabel()
        Me.FlatLabel15 = New Meth.FlatLabel()
        Me.ThirteenButton1 = New Meth.ThirteenButton()
        Me.ThirteenButton5 = New Meth.ThirteenButton()
        Me.ThirteenButton4 = New Meth.ThirteenButton()
        Me.ThirteenButton3 = New Meth.ThirteenButton()
        Me.ThirteenButton2 = New Meth.ThirteenButton()
        Me.AutoclickerTab = New System.Windows.Forms.TabPage()
        Me.FlatLabel36 = New Meth.FlatLabel()
        Me.FlatLabel35 = New Meth.FlatLabel()
        Me.FlatLabel34 = New Meth.FlatLabel()
        Me.ThirteenComboBox1 = New Meth.ThirteenComboBox()
        Me.ThirteenButton6 = New Meth.ThirteenButton()
        Me.ThirteenTextBox14 = New Meth.ThirteenTextBox()
        Me.FlatCheckBox4 = New Meth.FlatCheckBox()
        Me.FlatCheckBox3 = New Meth.FlatCheckBox()
        Me.FlatTrackBar1 = New Meth.FlatTrackBar()
        Me.FlatLabel4 = New Meth.FlatLabel()
        Me.FlatLabel3 = New Meth.FlatLabel()
        Me.MaximumCPS = New Meth.FlatTrackBar()
        Me.FlatLabel2 = New Meth.FlatLabel()
        Me.FlatLabel1 = New Meth.FlatLabel()
        Me.MinimumCPS = New Meth.FlatTrackBar()
        Me.WTapTab = New System.Windows.Forms.TabPage()
        Me.ThirteenButton7 = New Meth.ThirteenButton()
        Me.ThirteenTextBox15 = New Meth.ThirteenTextBox()
        Me.FlatCheckBox2 = New Meth.FlatCheckBox()
        Me.FlatLabel5 = New Meth.FlatLabel()
        Me.FlatLabel6 = New Meth.FlatLabel()
        Me.FlatTrackBar2 = New Meth.FlatTrackBar()
        Me.FlatLabel7 = New Meth.FlatLabel()
        Me.FlatLabel8 = New Meth.FlatLabel()
        Me.FlatTrackBar3 = New Meth.FlatTrackBar()
        Me.STapTab = New System.Windows.Forms.TabPage()
        Me.ThirteenButton9 = New Meth.ThirteenButton()
        Me.ThirteenTextBox16 = New Meth.ThirteenTextBox()
        Me.FlatCheckBox1 = New Meth.FlatCheckBox()
        Me.FlatLabel11 = New Meth.FlatLabel()
        Me.FlatLabel12 = New Meth.FlatLabel()
        Me.FlatTrackBar4 = New Meth.FlatTrackBar()
        Me.FlatLabel13 = New Meth.FlatLabel()
        Me.FlatLabel14 = New Meth.FlatLabel()
        Me.FlatTrackBar5 = New Meth.FlatTrackBar()
        Me.AutoPotTab = New System.Windows.Forms.TabPage()
        Me.ThirteenButton10 = New Meth.ThirteenButton()
        Me.ThirteenTextBox17 = New Meth.ThirteenTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FlatTrackBar6 = New Meth.FlatTrackBar()
        Me.FlatCheckBox5 = New Meth.FlatCheckBox()
        Me.FlatLabel27 = New Meth.FlatLabel()
        Me.FlatLabel26 = New Meth.FlatLabel()
        Me.FlatLabel25 = New Meth.FlatLabel()
        Me.ThirteenTextBox13 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox12 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox11 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox10 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox9 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox8 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox7 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox6 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox5 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox4 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox3 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox2 = New Meth.ThirteenTextBox()
        Me.FlatLabel24 = New Meth.FlatLabel()
        Me.FlatLabel23 = New Meth.FlatLabel()
        Me.FlatLabel22 = New Meth.FlatLabel()
        Me.FlatLabel21 = New Meth.FlatLabel()
        Me.FlatLabel20 = New Meth.FlatLabel()
        Me.FlatLabel19 = New Meth.FlatLabel()
        Me.FlatLabel18 = New Meth.FlatLabel()
        Me.FlatLabel17 = New Meth.FlatLabel()
        Me.FlatLabel16 = New Meth.FlatLabel()
        Me.AutoRodTab = New System.Windows.Forms.TabPage()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FlatTrackBar7 = New Meth.FlatTrackBar()
        Me.FlatLabel31 = New Meth.FlatLabel()
        Me.FlatLabel30 = New Meth.FlatLabel()
        Me.FlatLabel29 = New Meth.FlatLabel()
        Me.ThirteenTextBox21 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox20 = New Meth.ThirteenTextBox()
        Me.ThirteenTextBox19 = New Meth.ThirteenTextBox()
        Me.ThirteenButton11 = New Meth.ThirteenButton()
        Me.ThirteenTextBox18 = New Meth.ThirteenTextBox()
        Me.Miscellaneous = New System.Windows.Forms.TabPage()
        Me.FlatLabel33 = New Meth.FlatLabel()
        Me.FlatLabel32 = New Meth.FlatLabel()
        Me.FlatTrackBar8 = New Meth.FlatTrackBar()
        Me.FlatCheckBox7 = New Meth.FlatCheckBox()
        Me.FlatCheckBox6 = New Meth.FlatCheckBox()
        Me.picRainbow = New System.Windows.Forms.PictureBox()
        Me.FlatLabel10 = New Meth.FlatLabel()
        Me.FlatLabel9 = New Meth.FlatLabel()
        Me.ThirteenButton8 = New Meth.ThirteenButton()
        Me.ThirteenTextBox1 = New Meth.ThirteenTextBox()
        Me.DestructTab = New System.Windows.Forms.TabPage()
        Me.ThirteenButton12 = New Meth.ThirteenButton()
        Me.FlatLabel28 = New Meth.FlatLabel()
        Me.MainForm.SuspendLayout()
        Me.FlatTabControl1.SuspendLayout()
        Me.MainTab.SuspendLayout()
        Me.AutoclickerTab.SuspendLayout()
        Me.WTapTab.SuspendLayout()
        Me.STapTab.SuspendLayout()
        Me.AutoPotTab.SuspendLayout()
        Me.AutoRodTab.SuspendLayout()
        Me.Miscellaneous.SuspendLayout()
        CType(Me.picRainbow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DestructTab.SuspendLayout()
        Me.SuspendLayout()
        '
        'Autoclicker
        '
        '
        'WTap
        '
        '
        'STap
        '
        '
        'AutoPot
        '
        '
        'AutoRod
        '
        '
        'HideButton
        '
        '
        'Bind
        '
        Me.Bind.Interval = 20
        '
        'CustomRainbow
        '
        '
        'Prefetch
        '
        Me.Prefetch.Enabled = True
        '
        'MainForm
        '
        Me.MainForm.AccentColor = System.Drawing.Color.DodgerBlue
        Me.MainForm.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.MainForm.ColorScheme = Meth.Theme.ColorSchemes.Dark
        Me.MainForm.Controls.Add(Me.ThirteenControlBox1)
        Me.MainForm.Controls.Add(Me.FlatTabControl1)
        Me.MainForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainForm.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.MainForm.ForeColor = System.Drawing.Color.White
        Me.MainForm.Location = New System.Drawing.Point(0, 0)
        Me.MainForm.Name = "MainForm"
        Me.MainForm.Size = New System.Drawing.Size(520, 340)
        Me.MainForm.TabIndex = 7
        '
        'ThirteenControlBox1
        '
        Me.ThirteenControlBox1.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ThirteenControlBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenControlBox1.ColorScheme = Meth.ThirteenControlBox.ColorSchemes.Dark
        Me.ThirteenControlBox1.ForeColor = System.Drawing.Color.White
        Me.ThirteenControlBox1.Location = New System.Drawing.Point(417, 3)
        Me.ThirteenControlBox1.Name = "ThirteenControlBox1"
        Me.ThirteenControlBox1.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenControlBox1.TabIndex = 1
        Me.ThirteenControlBox1.Text = "ThirteenControlBox1"
        '
        'FlatTabControl1
        '
        Me.FlatTabControl1.ActiveColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(144, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.FlatTabControl1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTabControl1.Controls.Add(Me.MainTab)
        Me.FlatTabControl1.Controls.Add(Me.AutoclickerTab)
        Me.FlatTabControl1.Controls.Add(Me.WTapTab)
        Me.FlatTabControl1.Controls.Add(Me.STapTab)
        Me.FlatTabControl1.Controls.Add(Me.AutoPotTab)
        Me.FlatTabControl1.Controls.Add(Me.AutoRodTab)
        Me.FlatTabControl1.Controls.Add(Me.Miscellaneous)
        Me.FlatTabControl1.Controls.Add(Me.DestructTab)
        Me.FlatTabControl1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatTabControl1.ItemSize = New System.Drawing.Size(50, 20)
        Me.FlatTabControl1.Location = New System.Drawing.Point(3, 31)
        Me.FlatTabControl1.Name = "FlatTabControl1"
        Me.FlatTabControl1.SelectedIndex = 0
        Me.FlatTabControl1.Size = New System.Drawing.Size(514, 306)
        Me.FlatTabControl1.TabIndex = 0
        '
        'MainTab
        '
        Me.MainTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.MainTab.Controls.Add(Me.FlatLabel41)
        Me.MainTab.Controls.Add(Me.FlatLabel40)
        Me.MainTab.Controls.Add(Me.FlatLabel39)
        Me.MainTab.Controls.Add(Me.FlatLabel38)
        Me.MainTab.Controls.Add(Me.FlatLabel37)
        Me.MainTab.Controls.Add(Me.FlatLabel15)
        Me.MainTab.Controls.Add(Me.ThirteenButton1)
        Me.MainTab.Controls.Add(Me.ThirteenButton5)
        Me.MainTab.Controls.Add(Me.ThirteenButton4)
        Me.MainTab.Controls.Add(Me.ThirteenButton3)
        Me.MainTab.Controls.Add(Me.ThirteenButton2)
        Me.MainTab.ForeColor = System.Drawing.Color.White
        Me.MainTab.Location = New System.Drawing.Point(4, 24)
        Me.MainTab.Name = "MainTab"
        Me.MainTab.Padding = New System.Windows.Forms.Padding(3)
        Me.MainTab.Size = New System.Drawing.Size(506, 278)
        Me.MainTab.TabIndex = 0
        Me.MainTab.Text = "Main"
        '
        'FlatLabel41
        '
        Me.FlatLabel41.AutoSize = True
        Me.FlatLabel41.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel41.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel41.ForeColor = System.Drawing.Color.White
        Me.FlatLabel41.Location = New System.Drawing.Point(123, 196)
        Me.FlatLabel41.Name = "FlatLabel41"
        Me.FlatLabel41.Size = New System.Drawing.Size(24, 13)
        Me.FlatLabel41.TabIndex = 12
        Me.FlatLabel41.Text = "Off"
        '
        'FlatLabel40
        '
        Me.FlatLabel40.AutoSize = True
        Me.FlatLabel40.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel40.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel40.ForeColor = System.Drawing.Color.White
        Me.FlatLabel40.Location = New System.Drawing.Point(123, 160)
        Me.FlatLabel40.Name = "FlatLabel40"
        Me.FlatLabel40.Size = New System.Drawing.Size(24, 13)
        Me.FlatLabel40.TabIndex = 11
        Me.FlatLabel40.Text = "Off"
        '
        'FlatLabel39
        '
        Me.FlatLabel39.AutoSize = True
        Me.FlatLabel39.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel39.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel39.ForeColor = System.Drawing.Color.White
        Me.FlatLabel39.Location = New System.Drawing.Point(123, 124)
        Me.FlatLabel39.Name = "FlatLabel39"
        Me.FlatLabel39.Size = New System.Drawing.Size(24, 13)
        Me.FlatLabel39.TabIndex = 10
        Me.FlatLabel39.Text = "Off"
        '
        'FlatLabel38
        '
        Me.FlatLabel38.AutoSize = True
        Me.FlatLabel38.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel38.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel38.ForeColor = System.Drawing.Color.White
        Me.FlatLabel38.Location = New System.Drawing.Point(122, 88)
        Me.FlatLabel38.Name = "FlatLabel38"
        Me.FlatLabel38.Size = New System.Drawing.Size(24, 13)
        Me.FlatLabel38.TabIndex = 9
        Me.FlatLabel38.Text = "Off"
        '
        'FlatLabel37
        '
        Me.FlatLabel37.AutoSize = True
        Me.FlatLabel37.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel37.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel37.ForeColor = System.Drawing.Color.White
        Me.FlatLabel37.Location = New System.Drawing.Point(122, 52)
        Me.FlatLabel37.Name = "FlatLabel37"
        Me.FlatLabel37.Size = New System.Drawing.Size(24, 13)
        Me.FlatLabel37.TabIndex = 8
        Me.FlatLabel37.Text = "Off"
        '
        'FlatLabel15
        '
        Me.FlatLabel15.AutoSize = True
        Me.FlatLabel15.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel15.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel15.ForeColor = System.Drawing.Color.White
        Me.FlatLabel15.Location = New System.Drawing.Point(443, 263)
        Me.FlatLabel15.Name = "FlatLabel15"
        Me.FlatLabel15.Size = New System.Drawing.Size(57, 13)
        Me.FlatLabel15.TabIndex = 7
        Me.FlatLabel15.Text = "Meth v1.1"
        '
        'ThirteenButton1
        '
        Me.ThirteenButton1.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton1.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton1.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton1.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton1.Location = New System.Drawing.Point(6, 42)
        Me.ThirteenButton1.Name = "ThirteenButton1"
        Me.ThirteenButton1.Size = New System.Drawing.Size(110, 30)
        Me.ThirteenButton1.TabIndex = 6
        Me.ThirteenButton1.Text = "Clicker"
        Me.ThirteenButton1.UseVisualStyleBackColor = False
        '
        'ThirteenButton5
        '
        Me.ThirteenButton5.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton5.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton5.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton5.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton5.Location = New System.Drawing.Point(5, 186)
        Me.ThirteenButton5.Name = "ThirteenButton5"
        Me.ThirteenButton5.Size = New System.Drawing.Size(110, 30)
        Me.ThirteenButton5.TabIndex = 4
        Me.ThirteenButton5.Text = "Auto-Rod"
        Me.ThirteenButton5.UseVisualStyleBackColor = False
        '
        'ThirteenButton4
        '
        Me.ThirteenButton4.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton4.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton4.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton4.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton4.Location = New System.Drawing.Point(6, 150)
        Me.ThirteenButton4.Name = "ThirteenButton4"
        Me.ThirteenButton4.Size = New System.Drawing.Size(110, 30)
        Me.ThirteenButton4.TabIndex = 3
        Me.ThirteenButton4.Text = "Auto-Pot"
        Me.ThirteenButton4.UseVisualStyleBackColor = False
        '
        'ThirteenButton3
        '
        Me.ThirteenButton3.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton3.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton3.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton3.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton3.Location = New System.Drawing.Point(6, 114)
        Me.ThirteenButton3.Name = "ThirteenButton3"
        Me.ThirteenButton3.Size = New System.Drawing.Size(110, 30)
        Me.ThirteenButton3.TabIndex = 2
        Me.ThirteenButton3.Text = "S-Tap"
        Me.ThirteenButton3.UseVisualStyleBackColor = False
        '
        'ThirteenButton2
        '
        Me.ThirteenButton2.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton2.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton2.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton2.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton2.Location = New System.Drawing.Point(6, 78)
        Me.ThirteenButton2.Name = "ThirteenButton2"
        Me.ThirteenButton2.Size = New System.Drawing.Size(110, 30)
        Me.ThirteenButton2.TabIndex = 1
        Me.ThirteenButton2.Text = "W-Tap"
        Me.ThirteenButton2.UseVisualStyleBackColor = False
        '
        'AutoclickerTab
        '
        Me.AutoclickerTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel36)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel35)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel34)
        Me.AutoclickerTab.Controls.Add(Me.ThirteenComboBox1)
        Me.AutoclickerTab.Controls.Add(Me.ThirteenButton6)
        Me.AutoclickerTab.Controls.Add(Me.ThirteenTextBox14)
        Me.AutoclickerTab.Controls.Add(Me.FlatCheckBox4)
        Me.AutoclickerTab.Controls.Add(Me.FlatCheckBox3)
        Me.AutoclickerTab.Controls.Add(Me.FlatTrackBar1)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel4)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel3)
        Me.AutoclickerTab.Controls.Add(Me.MaximumCPS)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel2)
        Me.AutoclickerTab.Controls.Add(Me.FlatLabel1)
        Me.AutoclickerTab.Controls.Add(Me.MinimumCPS)
        Me.AutoclickerTab.Location = New System.Drawing.Point(4, 24)
        Me.AutoclickerTab.Name = "AutoclickerTab"
        Me.AutoclickerTab.Size = New System.Drawing.Size(506, 278)
        Me.AutoclickerTab.TabIndex = 7
        Me.AutoclickerTab.Text = "Clicker"
        '
        'FlatLabel36
        '
        Me.FlatLabel36.AutoSize = True
        Me.FlatLabel36.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel36.Font = New System.Drawing.Font("Segoe UI", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatLabel36.ForeColor = System.Drawing.Color.White
        Me.FlatLabel36.Location = New System.Drawing.Point(38, 264)
        Me.FlatLabel36.Name = "FlatLabel36"
        Me.FlatLabel36.Size = New System.Drawing.Size(454, 12)
        Me.FlatLabel36.TabIndex = 31
        Me.FlatLabel36.Text = "Because of the way Meth's randomization is coded, it will not have uniform distri" &
    "bution if the CPS values are too far."
        '
        'FlatLabel35
        '
        Me.FlatLabel35.AutoSize = True
        Me.FlatLabel35.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel35.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel35.ForeColor = System.Drawing.Color.White
        Me.FlatLabel35.Location = New System.Drawing.Point(92, 240)
        Me.FlatLabel35.Name = "FlatLabel35"
        Me.FlatLabel35.Size = New System.Drawing.Size(352, 13)
        Me.FlatLabel35.TabIndex = 30
        Me.FlatLabel35.Text = "While using ""Human Clicks"", don't put the CPS values too far apart."
        '
        'FlatLabel34
        '
        Me.FlatLabel34.AutoSize = True
        Me.FlatLabel34.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel34.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel34.ForeColor = System.Drawing.Color.White
        Me.FlatLabel34.Location = New System.Drawing.Point(407, 83)
        Me.FlatLabel34.Name = "FlatLabel34"
        Me.FlatLabel34.Size = New System.Drawing.Size(85, 13)
        Me.FlatLabel34.TabIndex = 29
        Me.FlatLabel34.Text = "Randomization"
        '
        'ThirteenComboBox1
        '
        Me.ThirteenComboBox1.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenComboBox1.ColorScheme = Meth.ThirteenComboBox.ColorSchemes.Dark
        Me.ThirteenComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ThirteenComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ThirteenComboBox1.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenComboBox1.ForeColor = System.Drawing.Color.White
        Me.ThirteenComboBox1.FormattingEnabled = True
        Me.ThirteenComboBox1.Items.AddRange(New Object() {"Human Clicks", "Simple Random"})
        Me.ThirteenComboBox1.Location = New System.Drawing.Point(390, 99)
        Me.ThirteenComboBox1.Name = "ThirteenComboBox1"
        Me.ThirteenComboBox1.Size = New System.Drawing.Size(111, 26)
        Me.ThirteenComboBox1.TabIndex = 28
        '
        'ThirteenButton6
        '
        Me.ThirteenButton6.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton6.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton6.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton6.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton6.Location = New System.Drawing.Point(390, 43)
        Me.ThirteenButton6.Name = "ThirteenButton6"
        Me.ThirteenButton6.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton6.TabIndex = 27
        Me.ThirteenButton6.Text = "Bind"
        Me.ThirteenButton6.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox14
        '
        Me.ThirteenTextBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox14.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox14.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox14.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox14.Location = New System.Drawing.Point(390, 12)
        Me.ThirteenTextBox14.MaxLength = 1
        Me.ThirteenTextBox14.Name = "ThirteenTextBox14"
        Me.ThirteenTextBox14.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox14.TabIndex = 26
        Me.ThirteenTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'FlatCheckBox4
        '
        Me.FlatCheckBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox4.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox4.Checked = False
        Me.FlatCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox4.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox4.Location = New System.Drawing.Point(33, 122)
        Me.FlatCheckBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox4.Name = "FlatCheckBox4"
        Me.FlatCheckBox4.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox4.Size = New System.Drawing.Size(88, 22)
        Me.FlatCheckBox4.TabIndex = 25
        Me.FlatCheckBox4.Text = "Minecraft Only?"
        '
        'FlatCheckBox3
        '
        Me.FlatCheckBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox3.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox3.Checked = False
        Me.FlatCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox3.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox3.Location = New System.Drawing.Point(33, 99)
        Me.FlatCheckBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox3.Name = "FlatCheckBox3"
        Me.FlatCheckBox3.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox3.Size = New System.Drawing.Size(46, 22)
        Me.FlatCheckBox3.TabIndex = 24
        Me.FlatCheckBox3.Text = "Jitter"
        '
        'FlatTrackBar1
        '
        Me.FlatTrackBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar1.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar1.Location = New System.Drawing.Point(95, 98)
        Me.FlatTrackBar1.Maximum = 10
        Me.FlatTrackBar1.Minimum = 0
        Me.FlatTrackBar1.Name = "FlatTrackBar1"
        Me.FlatTrackBar1.ShowValue = False
        Me.FlatTrackBar1.Size = New System.Drawing.Size(75, 23)
        Me.FlatTrackBar1.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar1.TabIndex = 8
        Me.FlatTrackBar1.Text = "FlatTrackBar1"
        Me.FlatTrackBar1.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar1.Value = 0
        '
        'FlatLabel4
        '
        Me.FlatLabel4.AutoSize = True
        Me.FlatLabel4.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel4.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel4.ForeColor = System.Drawing.Color.White
        Me.FlatLabel4.Location = New System.Drawing.Point(157, 53)
        Me.FlatLabel4.Name = "FlatLabel4"
        Me.FlatLabel4.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel4.TabIndex = 7
        Me.FlatLabel4.Text = "1"
        '
        'FlatLabel3
        '
        Me.FlatLabel3.AutoSize = True
        Me.FlatLabel3.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel3.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel3.ForeColor = System.Drawing.Color.White
        Me.FlatLabel3.Location = New System.Drawing.Point(30, 53)
        Me.FlatLabel3.Name = "FlatLabel3"
        Me.FlatLabel3.Size = New System.Drawing.Size(81, 13)
        Me.FlatLabel3.TabIndex = 6
        Me.FlatLabel3.Text = "Maximum CPS:"
        '
        'MaximumCPS
        '
        Me.MaximumCPS.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.MaximumCPS.HatchColor = System.Drawing.Color.DodgerBlue
        Me.MaximumCPS.Location = New System.Drawing.Point(5, 69)
        Me.MaximumCPS.Maximum = 20
        Me.MaximumCPS.Minimum = 1
        Me.MaximumCPS.Name = "MaximumCPS"
        Me.MaximumCPS.ShowValue = False
        Me.MaximumCPS.Size = New System.Drawing.Size(165, 23)
        Me.MaximumCPS.Style = Meth.FlatTrackBar._Style.Slider
        Me.MaximumCPS.TabIndex = 4
        Me.MaximumCPS.TrackColor = System.Drawing.Color.DodgerBlue
        Me.MaximumCPS.Value = 1
        '
        'FlatLabel2
        '
        Me.FlatLabel2.AutoSize = True
        Me.FlatLabel2.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel2.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel2.ForeColor = System.Drawing.Color.White
        Me.FlatLabel2.Location = New System.Drawing.Point(157, 10)
        Me.FlatLabel2.Name = "FlatLabel2"
        Me.FlatLabel2.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel2.TabIndex = 3
        Me.FlatLabel2.Text = "1"
        '
        'FlatLabel1
        '
        Me.FlatLabel1.AutoSize = True
        Me.FlatLabel1.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel1.ForeColor = System.Drawing.Color.White
        Me.FlatLabel1.Location = New System.Drawing.Point(30, 10)
        Me.FlatLabel1.Name = "FlatLabel1"
        Me.FlatLabel1.Size = New System.Drawing.Size(80, 13)
        Me.FlatLabel1.TabIndex = 2
        Me.FlatLabel1.Text = "Minimum CPS:"
        '
        'MinimumCPS
        '
        Me.MinimumCPS.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.MinimumCPS.HatchColor = System.Drawing.Color.DodgerBlue
        Me.MinimumCPS.Location = New System.Drawing.Point(5, 26)
        Me.MinimumCPS.Maximum = 20
        Me.MinimumCPS.Minimum = 1
        Me.MinimumCPS.Name = "MinimumCPS"
        Me.MinimumCPS.ShowValue = False
        Me.MinimumCPS.Size = New System.Drawing.Size(165, 23)
        Me.MinimumCPS.Style = Meth.FlatTrackBar._Style.Slider
        Me.MinimumCPS.TabIndex = 0
        Me.MinimumCPS.TrackColor = System.Drawing.Color.DodgerBlue
        Me.MinimumCPS.Value = 1
        '
        'WTapTab
        '
        Me.WTapTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.WTapTab.Controls.Add(Me.ThirteenButton7)
        Me.WTapTab.Controls.Add(Me.ThirteenTextBox15)
        Me.WTapTab.Controls.Add(Me.FlatCheckBox2)
        Me.WTapTab.Controls.Add(Me.FlatLabel5)
        Me.WTapTab.Controls.Add(Me.FlatLabel6)
        Me.WTapTab.Controls.Add(Me.FlatTrackBar2)
        Me.WTapTab.Controls.Add(Me.FlatLabel7)
        Me.WTapTab.Controls.Add(Me.FlatLabel8)
        Me.WTapTab.Controls.Add(Me.FlatTrackBar3)
        Me.WTapTab.Location = New System.Drawing.Point(4, 24)
        Me.WTapTab.Name = "WTapTab"
        Me.WTapTab.Size = New System.Drawing.Size(506, 278)
        Me.WTapTab.TabIndex = 2
        Me.WTapTab.Text = "W-Tap"
        '
        'ThirteenButton7
        '
        Me.ThirteenButton7.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton7.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton7.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton7.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton7.Location = New System.Drawing.Point(390, 43)
        Me.ThirteenButton7.Name = "ThirteenButton7"
        Me.ThirteenButton7.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton7.TabIndex = 25
        Me.ThirteenButton7.Text = "Bind"
        Me.ThirteenButton7.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox15
        '
        Me.ThirteenTextBox15.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox15.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox15.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox15.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox15.Location = New System.Drawing.Point(390, 12)
        Me.ThirteenTextBox15.MaxLength = 1
        Me.ThirteenTextBox15.Name = "ThirteenTextBox15"
        Me.ThirteenTextBox15.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox15.TabIndex = 24
        Me.ThirteenTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox2.Location = New System.Drawing.Point(33, 93)
        Me.FlatCheckBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(163, 22)
        Me.FlatCheckBox2.TabIndex = 23
        Me.FlatCheckBox2.Text = "W-Tap while autoclicking?"
        '
        'FlatLabel5
        '
        Me.FlatLabel5.AutoSize = True
        Me.FlatLabel5.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel5.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel5.ForeColor = System.Drawing.Color.White
        Me.FlatLabel5.Location = New System.Drawing.Point(157, 53)
        Me.FlatLabel5.Name = "FlatLabel5"
        Me.FlatLabel5.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel5.TabIndex = 13
        Me.FlatLabel5.Text = "1"
        '
        'FlatLabel6
        '
        Me.FlatLabel6.AutoSize = True
        Me.FlatLabel6.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel6.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel6.ForeColor = System.Drawing.Color.White
        Me.FlatLabel6.Location = New System.Drawing.Point(30, 53)
        Me.FlatLabel6.Name = "FlatLabel6"
        Me.FlatLabel6.Size = New System.Drawing.Size(90, 13)
        Me.FlatLabel6.TabIndex = 12
        Me.FlatLabel6.Text = "Maximum Delay:"
        '
        'FlatTrackBar2
        '
        Me.FlatTrackBar2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar2.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar2.Location = New System.Drawing.Point(5, 69)
        Me.FlatTrackBar2.Maximum = 500
        Me.FlatTrackBar2.Minimum = 1
        Me.FlatTrackBar2.Name = "FlatTrackBar2"
        Me.FlatTrackBar2.ShowValue = False
        Me.FlatTrackBar2.Size = New System.Drawing.Size(165, 23)
        Me.FlatTrackBar2.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar2.TabIndex = 11
        Me.FlatTrackBar2.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar2.Value = 1
        '
        'FlatLabel7
        '
        Me.FlatLabel7.AutoSize = True
        Me.FlatLabel7.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel7.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel7.ForeColor = System.Drawing.Color.White
        Me.FlatLabel7.Location = New System.Drawing.Point(157, 10)
        Me.FlatLabel7.Name = "FlatLabel7"
        Me.FlatLabel7.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel7.TabIndex = 10
        Me.FlatLabel7.Text = "1"
        '
        'FlatLabel8
        '
        Me.FlatLabel8.AutoSize = True
        Me.FlatLabel8.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel8.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel8.ForeColor = System.Drawing.Color.White
        Me.FlatLabel8.Location = New System.Drawing.Point(30, 10)
        Me.FlatLabel8.Name = "FlatLabel8"
        Me.FlatLabel8.Size = New System.Drawing.Size(89, 13)
        Me.FlatLabel8.TabIndex = 9
        Me.FlatLabel8.Text = "Minimum Delay:"
        '
        'FlatTrackBar3
        '
        Me.FlatTrackBar3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar3.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar3.Location = New System.Drawing.Point(5, 26)
        Me.FlatTrackBar3.Maximum = 500
        Me.FlatTrackBar3.Minimum = 1
        Me.FlatTrackBar3.Name = "FlatTrackBar3"
        Me.FlatTrackBar3.ShowValue = False
        Me.FlatTrackBar3.Size = New System.Drawing.Size(165, 23)
        Me.FlatTrackBar3.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar3.TabIndex = 8
        Me.FlatTrackBar3.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar3.Value = 1
        '
        'STapTab
        '
        Me.STapTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.STapTab.Controls.Add(Me.ThirteenButton9)
        Me.STapTab.Controls.Add(Me.ThirteenTextBox16)
        Me.STapTab.Controls.Add(Me.FlatCheckBox1)
        Me.STapTab.Controls.Add(Me.FlatLabel11)
        Me.STapTab.Controls.Add(Me.FlatLabel12)
        Me.STapTab.Controls.Add(Me.FlatTrackBar4)
        Me.STapTab.Controls.Add(Me.FlatLabel13)
        Me.STapTab.Controls.Add(Me.FlatLabel14)
        Me.STapTab.Controls.Add(Me.FlatTrackBar5)
        Me.STapTab.Location = New System.Drawing.Point(4, 24)
        Me.STapTab.Name = "STapTab"
        Me.STapTab.Size = New System.Drawing.Size(506, 278)
        Me.STapTab.TabIndex = 3
        Me.STapTab.Text = "S-Tap"
        '
        'ThirteenButton9
        '
        Me.ThirteenButton9.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton9.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton9.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton9.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton9.Location = New System.Drawing.Point(390, 43)
        Me.ThirteenButton9.Name = "ThirteenButton9"
        Me.ThirteenButton9.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton9.TabIndex = 24
        Me.ThirteenButton9.Text = "Bind"
        Me.ThirteenButton9.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox16
        '
        Me.ThirteenTextBox16.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox16.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox16.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox16.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox16.Location = New System.Drawing.Point(390, 12)
        Me.ThirteenTextBox16.MaxLength = 1
        Me.ThirteenTextBox16.Name = "ThirteenTextBox16"
        Me.ThirteenTextBox16.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox16.TabIndex = 23
        Me.ThirteenTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox1.Location = New System.Drawing.Point(33, 93)
        Me.FlatCheckBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(163, 22)
        Me.FlatCheckBox1.TabIndex = 22
        Me.FlatCheckBox1.Text = "S-Tap while autoclicking?"
        '
        'FlatLabel11
        '
        Me.FlatLabel11.AutoSize = True
        Me.FlatLabel11.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel11.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel11.ForeColor = System.Drawing.Color.White
        Me.FlatLabel11.Location = New System.Drawing.Point(157, 53)
        Me.FlatLabel11.Name = "FlatLabel11"
        Me.FlatLabel11.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel11.TabIndex = 20
        Me.FlatLabel11.Text = "1"
        '
        'FlatLabel12
        '
        Me.FlatLabel12.AutoSize = True
        Me.FlatLabel12.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel12.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel12.ForeColor = System.Drawing.Color.White
        Me.FlatLabel12.Location = New System.Drawing.Point(30, 53)
        Me.FlatLabel12.Name = "FlatLabel12"
        Me.FlatLabel12.Size = New System.Drawing.Size(90, 13)
        Me.FlatLabel12.TabIndex = 19
        Me.FlatLabel12.Text = "Maximum Delay:"
        '
        'FlatTrackBar4
        '
        Me.FlatTrackBar4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar4.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar4.Location = New System.Drawing.Point(5, 69)
        Me.FlatTrackBar4.Maximum = 500
        Me.FlatTrackBar4.Minimum = 1
        Me.FlatTrackBar4.Name = "FlatTrackBar4"
        Me.FlatTrackBar4.ShowValue = False
        Me.FlatTrackBar4.Size = New System.Drawing.Size(165, 23)
        Me.FlatTrackBar4.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar4.TabIndex = 18
        Me.FlatTrackBar4.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar4.Value = 1
        '
        'FlatLabel13
        '
        Me.FlatLabel13.AutoSize = True
        Me.FlatLabel13.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel13.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel13.ForeColor = System.Drawing.Color.White
        Me.FlatLabel13.Location = New System.Drawing.Point(157, 10)
        Me.FlatLabel13.Name = "FlatLabel13"
        Me.FlatLabel13.Size = New System.Drawing.Size(13, 13)
        Me.FlatLabel13.TabIndex = 17
        Me.FlatLabel13.Text = "1"
        '
        'FlatLabel14
        '
        Me.FlatLabel14.AutoSize = True
        Me.FlatLabel14.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel14.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel14.ForeColor = System.Drawing.Color.White
        Me.FlatLabel14.Location = New System.Drawing.Point(30, 10)
        Me.FlatLabel14.Name = "FlatLabel14"
        Me.FlatLabel14.Size = New System.Drawing.Size(89, 13)
        Me.FlatLabel14.TabIndex = 16
        Me.FlatLabel14.Text = "Minimum Delay:"
        '
        'FlatTrackBar5
        '
        Me.FlatTrackBar5.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar5.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar5.Location = New System.Drawing.Point(5, 26)
        Me.FlatTrackBar5.Maximum = 500
        Me.FlatTrackBar5.Minimum = 1
        Me.FlatTrackBar5.Name = "FlatTrackBar5"
        Me.FlatTrackBar5.ShowValue = False
        Me.FlatTrackBar5.Size = New System.Drawing.Size(165, 23)
        Me.FlatTrackBar5.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar5.TabIndex = 15
        Me.FlatTrackBar5.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar5.Value = 1
        '
        'AutoPotTab
        '
        Me.AutoPotTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.AutoPotTab.Controls.Add(Me.ThirteenButton10)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox17)
        Me.AutoPotTab.Controls.Add(Me.Label2)
        Me.AutoPotTab.Controls.Add(Me.Label1)
        Me.AutoPotTab.Controls.Add(Me.FlatTrackBar6)
        Me.AutoPotTab.Controls.Add(Me.FlatCheckBox5)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel27)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel26)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel25)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox13)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox12)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox11)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox10)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox9)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox8)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox7)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox6)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox5)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox4)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox3)
        Me.AutoPotTab.Controls.Add(Me.ThirteenTextBox2)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel24)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel23)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel22)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel21)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel20)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel19)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel18)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel17)
        Me.AutoPotTab.Controls.Add(Me.FlatLabel16)
        Me.AutoPotTab.Location = New System.Drawing.Point(4, 24)
        Me.AutoPotTab.Name = "AutoPotTab"
        Me.AutoPotTab.Size = New System.Drawing.Size(506, 278)
        Me.AutoPotTab.TabIndex = 4
        Me.AutoPotTab.Text = "Auto-Pot"
        '
        'ThirteenButton10
        '
        Me.ThirteenButton10.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton10.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton10.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton10.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton10.Location = New System.Drawing.Point(5, 39)
        Me.ThirteenButton10.Name = "ThirteenButton10"
        Me.ThirteenButton10.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton10.TabIndex = 29
        Me.ThirteenButton10.Text = "Bind"
        Me.ThirteenButton10.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox17
        '
        Me.ThirteenTextBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox17.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox17.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox17.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox17.Location = New System.Drawing.Point(5, 8)
        Me.ThirteenTextBox17.MaxLength = 1
        Me.ThirteenTextBox17.Name = "ThirteenTextBox17"
        Me.ThirteenTextBox17.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox17.TabIndex = 28
        Me.ThirteenTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(192, 218)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 19)
        Me.Label2.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(134, 217)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 19)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Delay:"
        '
        'FlatTrackBar6
        '
        Me.FlatTrackBar6.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar6.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar6.Location = New System.Drawing.Point(63, 187)
        Me.FlatTrackBar6.Maximum = 100
        Me.FlatTrackBar6.Minimum = 1
        Me.FlatTrackBar6.Name = "FlatTrackBar6"
        Me.FlatTrackBar6.ShowValue = False
        Me.FlatTrackBar6.Size = New System.Drawing.Size(259, 23)
        Me.FlatTrackBar6.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar6.TabIndex = 25
        Me.FlatTrackBar6.Text = "FlatTrackBar6"
        Me.FlatTrackBar6.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar6.Value = 75
        '
        'FlatCheckBox5
        '
        Me.FlatCheckBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox5.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox5.Checked = False
        Me.FlatCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox5.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox5.Location = New System.Drawing.Point(138, 158)
        Me.FlatCheckBox5.Name = "FlatCheckBox5"
        Me.FlatCheckBox5.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox5.Size = New System.Drawing.Size(100, 22)
        Me.FlatCheckBox5.TabIndex = 24
        Me.FlatCheckBox5.Text = "Auto-Soup?"
        '
        'FlatLabel27
        '
        Me.FlatLabel27.AutoSize = True
        Me.FlatLabel27.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel27.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel27.ForeColor = System.Drawing.Color.White
        Me.FlatLabel27.Location = New System.Drawing.Point(60, 101)
        Me.FlatLabel27.Name = "FlatLabel27"
        Me.FlatLabel27.Size = New System.Drawing.Size(33, 13)
        Me.FlatLabel27.TabIndex = 23
        Me.FlatLabel27.Text = "Drop"
        '
        'FlatLabel26
        '
        Me.FlatLabel26.AutoSize = True
        Me.FlatLabel26.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel26.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel26.ForeColor = System.Drawing.Color.White
        Me.FlatLabel26.Location = New System.Drawing.Point(267, 101)
        Me.FlatLabel26.Name = "FlatLabel26"
        Me.FlatLabel26.Size = New System.Drawing.Size(55, 13)
        Me.FlatLabel26.TabIndex = 22
        Me.FlatLabel26.Text = "Inventory"
        '
        'FlatLabel25
        '
        Me.FlatLabel25.AutoSize = True
        Me.FlatLabel25.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel25.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel25.ForeColor = System.Drawing.Color.White
        Me.FlatLabel25.Location = New System.Drawing.Point(167, 101)
        Me.FlatLabel25.Name = "FlatLabel25"
        Me.FlatLabel25.Size = New System.Drawing.Size(43, 13)
        Me.FlatLabel25.TabIndex = 21
        Me.FlatLabel25.Text = "Hotkey"
        '
        'ThirteenTextBox13
        '
        Me.ThirteenTextBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox13.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox13.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox13.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox13.Location = New System.Drawing.Point(244, 127)
        Me.ThirteenTextBox13.Name = "ThirteenTextBox13"
        Me.ThirteenTextBox13.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox13.TabIndex = 20
        Me.ThirteenTextBox13.Text = "e"
        Me.ThirteenTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox12
        '
        Me.ThirteenTextBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox12.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox12.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox12.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox12.Location = New System.Drawing.Point(138, 127)
        Me.ThirteenTextBox12.MaxLength = 1
        Me.ThirteenTextBox12.Name = "ThirteenTextBox12"
        Me.ThirteenTextBox12.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox12.TabIndex = 19
        Me.ThirteenTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox11
        '
        Me.ThirteenTextBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox11.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox11.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox11.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox11.Location = New System.Drawing.Point(403, 248)
        Me.ThirteenTextBox11.MaxLength = 1
        Me.ThirteenTextBox11.Name = "ThirteenTextBox11"
        Me.ThirteenTextBox11.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox11.TabIndex = 17
        Me.ThirteenTextBox11.Text = "9"
        Me.ThirteenTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox10
        '
        Me.ThirteenTextBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox10.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox10.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox10.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox10.Location = New System.Drawing.Point(403, 218)
        Me.ThirteenTextBox10.MaxLength = 1
        Me.ThirteenTextBox10.Name = "ThirteenTextBox10"
        Me.ThirteenTextBox10.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox10.TabIndex = 8
        Me.ThirteenTextBox10.Text = "8"
        Me.ThirteenTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox9
        '
        Me.ThirteenTextBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox9.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox9.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox9.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox9.Location = New System.Drawing.Point(403, 189)
        Me.ThirteenTextBox9.MaxLength = 1
        Me.ThirteenTextBox9.Name = "ThirteenTextBox9"
        Me.ThirteenTextBox9.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox9.TabIndex = 7
        Me.ThirteenTextBox9.Text = "7"
        Me.ThirteenTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox8
        '
        Me.ThirteenTextBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox8.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox8.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox8.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox8.Location = New System.Drawing.Point(403, 158)
        Me.ThirteenTextBox8.MaxLength = 1
        Me.ThirteenTextBox8.Name = "ThirteenTextBox8"
        Me.ThirteenTextBox8.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox8.TabIndex = 6
        Me.ThirteenTextBox8.Text = "6"
        Me.ThirteenTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox7
        '
        Me.ThirteenTextBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox7.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox7.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox7.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox7.Location = New System.Drawing.Point(403, 127)
        Me.ThirteenTextBox7.MaxLength = 1
        Me.ThirteenTextBox7.Name = "ThirteenTextBox7"
        Me.ThirteenTextBox7.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox7.TabIndex = 5
        Me.ThirteenTextBox7.Text = "5"
        Me.ThirteenTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox6
        '
        Me.ThirteenTextBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox6.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox6.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox6.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox6.Location = New System.Drawing.Point(403, 96)
        Me.ThirteenTextBox6.MaxLength = 1
        Me.ThirteenTextBox6.Name = "ThirteenTextBox6"
        Me.ThirteenTextBox6.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox6.TabIndex = 4
        Me.ThirteenTextBox6.Text = "4"
        Me.ThirteenTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox5
        '
        Me.ThirteenTextBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox5.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox5.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox5.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox5.Location = New System.Drawing.Point(403, 65)
        Me.ThirteenTextBox5.MaxLength = 1
        Me.ThirteenTextBox5.Name = "ThirteenTextBox5"
        Me.ThirteenTextBox5.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox5.TabIndex = 3
        Me.ThirteenTextBox5.Text = "3"
        Me.ThirteenTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox4
        '
        Me.ThirteenTextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox4.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox4.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox4.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox4.Location = New System.Drawing.Point(403, 34)
        Me.ThirteenTextBox4.MaxLength = 1
        Me.ThirteenTextBox4.Name = "ThirteenTextBox4"
        Me.ThirteenTextBox4.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox4.TabIndex = 2
        Me.ThirteenTextBox4.Text = "2"
        Me.ThirteenTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox3
        '
        Me.ThirteenTextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox3.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox3.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox3.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox3.Location = New System.Drawing.Point(403, 3)
        Me.ThirteenTextBox3.MaxLength = 1
        Me.ThirteenTextBox3.Name = "ThirteenTextBox3"
        Me.ThirteenTextBox3.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox3.TabIndex = 1
        Me.ThirteenTextBox3.Text = "1"
        Me.ThirteenTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox2
        '
        Me.ThirteenTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox2.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox2.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox2.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox2.Location = New System.Drawing.Point(32, 127)
        Me.ThirteenTextBox2.Name = "ThirteenTextBox2"
        Me.ThirteenTextBox2.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox2.TabIndex = 0
        Me.ThirteenTextBox2.Text = "q"
        Me.ThirteenTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'FlatLabel24
        '
        Me.FlatLabel24.AutoSize = True
        Me.FlatLabel24.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel24.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel24.ForeColor = System.Drawing.Color.White
        Me.FlatLabel24.Location = New System.Drawing.Point(361, 253)
        Me.FlatLabel24.Name = "FlatLabel24"
        Me.FlatLabel24.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel24.TabIndex = 18
        Me.FlatLabel24.Text = "Slot 9"
        '
        'FlatLabel23
        '
        Me.FlatLabel23.AutoSize = True
        Me.FlatLabel23.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel23.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel23.ForeColor = System.Drawing.Color.White
        Me.FlatLabel23.Location = New System.Drawing.Point(361, 223)
        Me.FlatLabel23.Name = "FlatLabel23"
        Me.FlatLabel23.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel23.TabIndex = 16
        Me.FlatLabel23.Text = "Slot 8"
        '
        'FlatLabel22
        '
        Me.FlatLabel22.AutoSize = True
        Me.FlatLabel22.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel22.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel22.ForeColor = System.Drawing.Color.White
        Me.FlatLabel22.Location = New System.Drawing.Point(361, 194)
        Me.FlatLabel22.Name = "FlatLabel22"
        Me.FlatLabel22.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel22.TabIndex = 15
        Me.FlatLabel22.Text = "Slot 7"
        '
        'FlatLabel21
        '
        Me.FlatLabel21.AutoSize = True
        Me.FlatLabel21.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel21.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel21.ForeColor = System.Drawing.Color.White
        Me.FlatLabel21.Location = New System.Drawing.Point(361, 163)
        Me.FlatLabel21.Name = "FlatLabel21"
        Me.FlatLabel21.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel21.TabIndex = 14
        Me.FlatLabel21.Text = "Slot 6"
        '
        'FlatLabel20
        '
        Me.FlatLabel20.AutoSize = True
        Me.FlatLabel20.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel20.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel20.ForeColor = System.Drawing.Color.White
        Me.FlatLabel20.Location = New System.Drawing.Point(361, 132)
        Me.FlatLabel20.Name = "FlatLabel20"
        Me.FlatLabel20.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel20.TabIndex = 13
        Me.FlatLabel20.Text = "Slot 5"
        '
        'FlatLabel19
        '
        Me.FlatLabel19.AutoSize = True
        Me.FlatLabel19.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel19.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel19.ForeColor = System.Drawing.Color.White
        Me.FlatLabel19.Location = New System.Drawing.Point(361, 101)
        Me.FlatLabel19.Name = "FlatLabel19"
        Me.FlatLabel19.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel19.TabIndex = 12
        Me.FlatLabel19.Text = "Slot 4"
        '
        'FlatLabel18
        '
        Me.FlatLabel18.AutoSize = True
        Me.FlatLabel18.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel18.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel18.ForeColor = System.Drawing.Color.White
        Me.FlatLabel18.Location = New System.Drawing.Point(361, 70)
        Me.FlatLabel18.Name = "FlatLabel18"
        Me.FlatLabel18.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel18.TabIndex = 11
        Me.FlatLabel18.Text = "Slot 3"
        '
        'FlatLabel17
        '
        Me.FlatLabel17.AutoSize = True
        Me.FlatLabel17.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel17.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel17.ForeColor = System.Drawing.Color.White
        Me.FlatLabel17.Location = New System.Drawing.Point(361, 39)
        Me.FlatLabel17.Name = "FlatLabel17"
        Me.FlatLabel17.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel17.TabIndex = 10
        Me.FlatLabel17.Text = "Slot 2"
        '
        'FlatLabel16
        '
        Me.FlatLabel16.AutoSize = True
        Me.FlatLabel16.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel16.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel16.ForeColor = System.Drawing.Color.White
        Me.FlatLabel16.Location = New System.Drawing.Point(361, 8)
        Me.FlatLabel16.Name = "FlatLabel16"
        Me.FlatLabel16.Size = New System.Drawing.Size(36, 13)
        Me.FlatLabel16.TabIndex = 9
        Me.FlatLabel16.Text = "Slot 1"
        '
        'AutoRodTab
        '
        Me.AutoRodTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.AutoRodTab.Controls.Add(Me.Label3)
        Me.AutoRodTab.Controls.Add(Me.Label4)
        Me.AutoRodTab.Controls.Add(Me.FlatTrackBar7)
        Me.AutoRodTab.Controls.Add(Me.FlatLabel31)
        Me.AutoRodTab.Controls.Add(Me.FlatLabel30)
        Me.AutoRodTab.Controls.Add(Me.FlatLabel29)
        Me.AutoRodTab.Controls.Add(Me.ThirteenTextBox21)
        Me.AutoRodTab.Controls.Add(Me.ThirteenTextBox20)
        Me.AutoRodTab.Controls.Add(Me.ThirteenTextBox19)
        Me.AutoRodTab.Controls.Add(Me.ThirteenButton11)
        Me.AutoRodTab.Controls.Add(Me.ThirteenTextBox18)
        Me.AutoRodTab.Location = New System.Drawing.Point(4, 24)
        Me.AutoRodTab.Name = "AutoRodTab"
        Me.AutoRodTab.Size = New System.Drawing.Size(506, 278)
        Me.AutoRodTab.TabIndex = 5
        Me.AutoRodTab.Text = "Auto-Rod"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(192, 218)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 19)
        Me.Label3.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(134, 217)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 19)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Delay:"
        '
        'FlatTrackBar7
        '
        Me.FlatTrackBar7.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar7.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar7.Location = New System.Drawing.Point(63, 187)
        Me.FlatTrackBar7.Maximum = 100
        Me.FlatTrackBar7.Minimum = 1
        Me.FlatTrackBar7.Name = "FlatTrackBar7"
        Me.FlatTrackBar7.ShowValue = False
        Me.FlatTrackBar7.Size = New System.Drawing.Size(259, 23)
        Me.FlatTrackBar7.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar7.TabIndex = 28
        Me.FlatTrackBar7.Text = "FlatTrackBar7"
        Me.FlatTrackBar7.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar7.Value = 75
        '
        'FlatLabel31
        '
        Me.FlatLabel31.AutoSize = True
        Me.FlatLabel31.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel31.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel31.ForeColor = System.Drawing.Color.White
        Me.FlatLabel31.Location = New System.Drawing.Point(267, 101)
        Me.FlatLabel31.Name = "FlatLabel31"
        Me.FlatLabel31.Size = New System.Drawing.Size(40, 13)
        Me.FlatLabel31.TabIndex = 25
        Me.FlatLabel31.Text = "Sword"
        '
        'FlatLabel30
        '
        Me.FlatLabel30.AutoSize = True
        Me.FlatLabel30.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel30.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel30.ForeColor = System.Drawing.Color.White
        Me.FlatLabel30.Location = New System.Drawing.Point(60, 101)
        Me.FlatLabel30.Name = "FlatLabel30"
        Me.FlatLabel30.Size = New System.Drawing.Size(28, 13)
        Me.FlatLabel30.TabIndex = 24
        Me.FlatLabel30.Text = "Rod"
        '
        'FlatLabel29
        '
        Me.FlatLabel29.AutoSize = True
        Me.FlatLabel29.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel29.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel29.ForeColor = System.Drawing.Color.White
        Me.FlatLabel29.Location = New System.Drawing.Point(167, 101)
        Me.FlatLabel29.Name = "FlatLabel29"
        Me.FlatLabel29.Size = New System.Drawing.Size(43, 13)
        Me.FlatLabel29.TabIndex = 23
        Me.FlatLabel29.Text = "Hotkey"
        '
        'ThirteenTextBox21
        '
        Me.ThirteenTextBox21.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox21.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox21.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox21.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox21.Location = New System.Drawing.Point(32, 127)
        Me.ThirteenTextBox21.MaxLength = 1
        Me.ThirteenTextBox21.Name = "ThirteenTextBox21"
        Me.ThirteenTextBox21.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox21.TabIndex = 22
        Me.ThirteenTextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox20
        '
        Me.ThirteenTextBox20.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox20.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox20.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox20.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox20.Location = New System.Drawing.Point(244, 127)
        Me.ThirteenTextBox20.MaxLength = 1
        Me.ThirteenTextBox20.Name = "ThirteenTextBox20"
        Me.ThirteenTextBox20.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox20.TabIndex = 21
        Me.ThirteenTextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenTextBox19
        '
        Me.ThirteenTextBox19.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox19.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox19.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox19.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox19.Location = New System.Drawing.Point(138, 127)
        Me.ThirteenTextBox19.MaxLength = 1
        Me.ThirteenTextBox19.Name = "ThirteenTextBox19"
        Me.ThirteenTextBox19.Size = New System.Drawing.Size(100, 25)
        Me.ThirteenTextBox19.TabIndex = 20
        Me.ThirteenTextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ThirteenButton11
        '
        Me.ThirteenButton11.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton11.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton11.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton11.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton11.Location = New System.Drawing.Point(390, 43)
        Me.ThirteenButton11.Name = "ThirteenButton11"
        Me.ThirteenButton11.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton11.TabIndex = 15
        Me.ThirteenButton11.Text = "Bind"
        Me.ThirteenButton11.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox18
        '
        Me.ThirteenTextBox18.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox18.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox18.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox18.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox18.Location = New System.Drawing.Point(390, 12)
        Me.ThirteenTextBox18.MaxLength = 1
        Me.ThirteenTextBox18.Name = "ThirteenTextBox18"
        Me.ThirteenTextBox18.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox18.TabIndex = 14
        Me.ThirteenTextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Miscellaneous
        '
        Me.Miscellaneous.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.Miscellaneous.Controls.Add(Me.FlatLabel33)
        Me.Miscellaneous.Controls.Add(Me.FlatLabel32)
        Me.Miscellaneous.Controls.Add(Me.FlatTrackBar8)
        Me.Miscellaneous.Controls.Add(Me.FlatCheckBox7)
        Me.Miscellaneous.Controls.Add(Me.FlatCheckBox6)
        Me.Miscellaneous.Controls.Add(Me.picRainbow)
        Me.Miscellaneous.Controls.Add(Me.FlatLabel10)
        Me.Miscellaneous.Controls.Add(Me.FlatLabel9)
        Me.Miscellaneous.Controls.Add(Me.ThirteenButton8)
        Me.Miscellaneous.Controls.Add(Me.ThirteenTextBox1)
        Me.Miscellaneous.Location = New System.Drawing.Point(4, 24)
        Me.Miscellaneous.Name = "Miscellaneous"
        Me.Miscellaneous.Size = New System.Drawing.Size(506, 278)
        Me.Miscellaneous.TabIndex = 8
        Me.Miscellaneous.Text = "Misc"
        '
        'FlatLabel33
        '
        Me.FlatLabel33.AutoSize = True
        Me.FlatLabel33.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel33.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel33.ForeColor = System.Drawing.Color.White
        Me.FlatLabel33.Location = New System.Drawing.Point(350, 210)
        Me.FlatLabel33.Name = "FlatLabel33"
        Me.FlatLabel33.Size = New System.Drawing.Size(25, 13)
        Me.FlatLabel33.TabIndex = 28
        Me.FlatLabel33.Text = "100"
        '
        'FlatLabel32
        '
        Me.FlatLabel32.AutoSize = True
        Me.FlatLabel32.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel32.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel32.ForeColor = System.Drawing.Color.White
        Me.FlatLabel32.Location = New System.Drawing.Point(257, 210)
        Me.FlatLabel32.Name = "FlatLabel32"
        Me.FlatLabel32.Size = New System.Drawing.Size(87, 13)
        Me.FlatLabel32.TabIndex = 27
        Me.FlatLabel32.Text = "Rainbow Delay:"
        '
        'FlatTrackBar8
        '
        Me.FlatTrackBar8.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatTrackBar8.HatchColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar8.Location = New System.Drawing.Point(249, 226)
        Me.FlatTrackBar8.Maximum = 250
        Me.FlatTrackBar8.Minimum = 1
        Me.FlatTrackBar8.Name = "FlatTrackBar8"
        Me.FlatTrackBar8.ShowValue = False
        Me.FlatTrackBar8.Size = New System.Drawing.Size(105, 23)
        Me.FlatTrackBar8.Style = Meth.FlatTrackBar._Style.Slider
        Me.FlatTrackBar8.TabIndex = 26
        Me.FlatTrackBar8.Text = "FlatTrackBar8"
        Me.FlatTrackBar8.TrackColor = System.Drawing.Color.DodgerBlue
        Me.FlatTrackBar8.Value = 100
        '
        'FlatCheckBox7
        '
        Me.FlatCheckBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox7.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox7.Checked = False
        Me.FlatCheckBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox7.Location = New System.Drawing.Point(156, 224)
        Me.FlatCheckBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox7.Name = "FlatCheckBox7"
        Me.FlatCheckBox7.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox7.Size = New System.Drawing.Size(87, 22)
        Me.FlatCheckBox7.TabIndex = 25
        Me.FlatCheckBox7.Text = "Rainbow?"
        '
        'FlatCheckBox6
        '
        Me.FlatCheckBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.FlatCheckBox6.BaseColor = System.Drawing.Color.DimGray
        Me.FlatCheckBox6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox6.Checked = True
        Me.FlatCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox6.Location = New System.Drawing.Point(156, 198)
        Me.FlatCheckBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.FlatCheckBox6.Name = "FlatCheckBox6"
        Me.FlatCheckBox6.Options = Meth.FlatCheckBox._Options.Style1
        Me.FlatCheckBox6.Size = New System.Drawing.Size(163, 22)
        Me.FlatCheckBox6.TabIndex = 24
        Me.FlatCheckBox6.Text = "Custom color?"
        '
        'picRainbow
        '
        Me.picRainbow.BackColor = System.Drawing.SystemColors.Control
        Me.picRainbow.Location = New System.Drawing.Point(156, 162)
        Me.picRainbow.Name = "picRainbow"
        Me.picRainbow.Size = New System.Drawing.Size(198, 31)
        Me.picRainbow.TabIndex = 16
        Me.picRainbow.TabStop = False
        '
        'FlatLabel10
        '
        Me.FlatLabel10.AutoSize = True
        Me.FlatLabel10.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel10.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel10.ForeColor = System.Drawing.Color.White
        Me.FlatLabel10.Location = New System.Drawing.Point(216, 79)
        Me.FlatLabel10.Name = "FlatLabel10"
        Me.FlatLabel10.Size = New System.Drawing.Size(90, 13)
        Me.FlatLabel10.TabIndex = 15
        Me.FlatLabel10.Text = "Toggle Visibility:"
        '
        'FlatLabel9
        '
        Me.FlatLabel9.AutoSize = True
        Me.FlatLabel9.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel9.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatLabel9.ForeColor = System.Drawing.Color.White
        Me.FlatLabel9.Location = New System.Drawing.Point(120, 101)
        Me.FlatLabel9.Name = "FlatLabel9"
        Me.FlatLabel9.Size = New System.Drawing.Size(80, 17)
        Me.FlatLabel9.TabIndex = 14
        Me.FlatLabel9.Text = "LEFT CTRL +"
        '
        'ThirteenButton8
        '
        Me.ThirteenButton8.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton8.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton8.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton8.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton8.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton8.Location = New System.Drawing.Point(203, 126)
        Me.ThirteenButton8.Name = "ThirteenButton8"
        Me.ThirteenButton8.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton8.TabIndex = 13
        Me.ThirteenButton8.Text = "Bind"
        Me.ThirteenButton8.UseVisualStyleBackColor = False
        '
        'ThirteenTextBox1
        '
        Me.ThirteenTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ThirteenTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ThirteenTextBox1.ColorScheme = Meth.ThirteenTextBox.ColorSchemes.Dark
        Me.ThirteenTextBox1.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenTextBox1.ForeColor = System.Drawing.Color.White
        Me.ThirteenTextBox1.Location = New System.Drawing.Point(203, 95)
        Me.ThirteenTextBox1.MaxLength = 1
        Me.ThirteenTextBox1.Name = "ThirteenTextBox1"
        Me.ThirteenTextBox1.Size = New System.Drawing.Size(111, 25)
        Me.ThirteenTextBox1.TabIndex = 12
        Me.ThirteenTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DestructTab
        '
        Me.DestructTab.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.DestructTab.Controls.Add(Me.ThirteenButton12)
        Me.DestructTab.Controls.Add(Me.FlatLabel28)
        Me.DestructTab.Location = New System.Drawing.Point(4, 24)
        Me.DestructTab.Name = "DestructTab"
        Me.DestructTab.Padding = New System.Windows.Forms.Padding(3)
        Me.DestructTab.Size = New System.Drawing.Size(506, 278)
        Me.DestructTab.TabIndex = 1
        Me.DestructTab.Text = "Destruct"
        '
        'ThirteenButton12
        '
        Me.ThirteenButton12.AccentColor = System.Drawing.Color.DodgerBlue
        Me.ThirteenButton12.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ThirteenButton12.ColorScheme = Meth.ThirteenButton.ColorSchemes.Dark
        Me.ThirteenButton12.Font = New System.Drawing.Font("Segoe UI Semilight", 9.75!)
        Me.ThirteenButton12.ForeColor = System.Drawing.Color.White
        Me.ThirteenButton12.Location = New System.Drawing.Point(203, 126)
        Me.ThirteenButton12.Name = "ThirteenButton12"
        Me.ThirteenButton12.Size = New System.Drawing.Size(111, 30)
        Me.ThirteenButton12.TabIndex = 1
        Me.ThirteenButton12.Text = "Destruct"
        Me.ThirteenButton12.UseVisualStyleBackColor = False
        '
        'FlatLabel28
        '
        Me.FlatLabel28.AutoSize = True
        Me.FlatLabel28.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel28.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel28.ForeColor = System.Drawing.Color.White
        Me.FlatLabel28.Location = New System.Drawing.Point(71, 262)
        Me.FlatLabel28.Name = "FlatLabel28"
        Me.FlatLabel28.Size = New System.Drawing.Size(374, 13)
        Me.FlatLabel28.TabIndex = 0
        Me.FlatLabel28.Text = "Due to the way Meth is coded, you are responsible for deleting the file."
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(520, 340)
        Me.Controls.Add(Me.MainForm)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Main"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.MainForm.ResumeLayout(False)
        Me.FlatTabControl1.ResumeLayout(False)
        Me.MainTab.ResumeLayout(False)
        Me.MainTab.PerformLayout()
        Me.AutoclickerTab.ResumeLayout(False)
        Me.AutoclickerTab.PerformLayout()
        Me.WTapTab.ResumeLayout(False)
        Me.WTapTab.PerformLayout()
        Me.STapTab.ResumeLayout(False)
        Me.STapTab.PerformLayout()
        Me.AutoPotTab.ResumeLayout(False)
        Me.AutoPotTab.PerformLayout()
        Me.AutoRodTab.ResumeLayout(False)
        Me.AutoRodTab.PerformLayout()
        Me.Miscellaneous.ResumeLayout(False)
        Me.Miscellaneous.PerformLayout()
        CType(Me.picRainbow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DestructTab.ResumeLayout(False)
        Me.DestructTab.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Autoclicker As Timer
    Friend WithEvents WTap As Timer
    Friend WithEvents STap As Timer
    Friend WithEvents AutoPot As Timer
    Friend WithEvents AutoRod As Timer
    Friend WithEvents HideButton As Timer
    Friend WithEvents MainForm As Theme
    Friend WithEvents ThirteenControlBox1 As ThirteenControlBox
    Friend WithEvents FlatTabControl1 As FlatTabControl
    Friend WithEvents MainTab As TabPage
    Friend WithEvents ThirteenButton1 As ThirteenButton
    Friend WithEvents ThirteenButton5 As ThirteenButton
    Friend WithEvents ThirteenButton4 As ThirteenButton
    Friend WithEvents ThirteenButton3 As ThirteenButton
    Friend WithEvents ThirteenButton2 As ThirteenButton
    Friend WithEvents AutoclickerTab As TabPage
    Friend WithEvents ThirteenButton6 As ThirteenButton
    Friend WithEvents ThirteenTextBox14 As ThirteenTextBox
    Friend WithEvents FlatCheckBox4 As FlatCheckBox
    Friend WithEvents FlatCheckBox3 As FlatCheckBox
    Friend WithEvents FlatTrackBar1 As FlatTrackBar
    Friend WithEvents FlatLabel4 As FlatLabel
    Friend WithEvents FlatLabel3 As FlatLabel
    Friend WithEvents MaximumCPS As FlatTrackBar
    Friend WithEvents FlatLabel2 As FlatLabel
    Friend WithEvents FlatLabel1 As FlatLabel
    Friend WithEvents MinimumCPS As FlatTrackBar
    Friend WithEvents WTapTab As TabPage
    Friend WithEvents FlatCheckBox2 As FlatCheckBox
    Friend WithEvents FlatLabel5 As FlatLabel
    Friend WithEvents FlatLabel6 As FlatLabel
    Friend WithEvents FlatTrackBar2 As FlatTrackBar
    Friend WithEvents FlatLabel7 As FlatLabel
    Friend WithEvents FlatLabel8 As FlatLabel
    Friend WithEvents FlatTrackBar3 As FlatTrackBar
    Friend WithEvents STapTab As TabPage
    Friend WithEvents FlatCheckBox1 As FlatCheckBox
    Friend WithEvents FlatLabel11 As FlatLabel
    Friend WithEvents FlatLabel12 As FlatLabel
    Friend WithEvents FlatTrackBar4 As FlatTrackBar
    Friend WithEvents FlatLabel13 As FlatLabel
    Friend WithEvents FlatLabel14 As FlatLabel
    Friend WithEvents FlatTrackBar5 As FlatTrackBar
    Friend WithEvents AutoPotTab As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents FlatTrackBar6 As FlatTrackBar
    Friend WithEvents FlatCheckBox5 As FlatCheckBox
    Friend WithEvents FlatLabel27 As FlatLabel
    Friend WithEvents FlatLabel26 As FlatLabel
    Friend WithEvents FlatLabel25 As FlatLabel
    Friend WithEvents ThirteenTextBox13 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox12 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox11 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox10 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox9 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox8 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox7 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox6 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox5 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox4 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox3 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox2 As ThirteenTextBox
    Friend WithEvents FlatLabel24 As FlatLabel
    Friend WithEvents FlatLabel23 As FlatLabel
    Friend WithEvents FlatLabel22 As FlatLabel
    Friend WithEvents FlatLabel21 As FlatLabel
    Friend WithEvents FlatLabel20 As FlatLabel
    Friend WithEvents FlatLabel19 As FlatLabel
    Friend WithEvents FlatLabel18 As FlatLabel
    Friend WithEvents FlatLabel17 As FlatLabel
    Friend WithEvents FlatLabel16 As FlatLabel
    Friend WithEvents AutoRodTab As TabPage
    Friend WithEvents Miscellaneous As TabPage
    Friend WithEvents FlatLabel10 As FlatLabel
    Friend WithEvents FlatLabel9 As FlatLabel
    Friend WithEvents ThirteenButton8 As ThirteenButton
    Friend WithEvents ThirteenTextBox1 As ThirteenTextBox
    Friend WithEvents DestructTab As TabPage
    Friend WithEvents ThirteenButton7 As ThirteenButton
    Friend WithEvents ThirteenTextBox15 As ThirteenTextBox
    Friend WithEvents ThirteenButton9 As ThirteenButton
    Friend WithEvents ThirteenTextBox16 As ThirteenTextBox
    Friend WithEvents ThirteenButton10 As ThirteenButton
    Friend WithEvents ThirteenTextBox17 As ThirteenTextBox
    Friend WithEvents ThirteenButton11 As ThirteenButton
    Friend WithEvents ThirteenTextBox18 As ThirteenTextBox
    Friend WithEvents Bind As Timer
    Friend WithEvents ThirteenTextBox21 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox20 As ThirteenTextBox
    Friend WithEvents ThirteenTextBox19 As ThirteenTextBox
    Friend WithEvents FlatLabel28 As FlatLabel
    Friend WithEvents ThirteenButton12 As ThirteenButton
    Friend WithEvents FlatLabel31 As FlatLabel
    Friend WithEvents FlatLabel30 As FlatLabel
    Friend WithEvents FlatLabel29 As FlatLabel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents FlatTrackBar7 As FlatTrackBar
    Friend WithEvents picRainbow As PictureBox
    Friend WithEvents FlatCheckBox7 As FlatCheckBox
    Friend WithEvents FlatCheckBox6 As FlatCheckBox
    Friend WithEvents CustomRainbow As Timer
    Friend WithEvents FlatLabel33 As FlatLabel
    Friend WithEvents FlatLabel32 As FlatLabel
    Friend WithEvents FlatTrackBar8 As FlatTrackBar
    Friend WithEvents CustomColor As Timer
    Friend WithEvents FlatLabel34 As FlatLabel
    Friend WithEvents ThirteenComboBox1 As ThirteenComboBox
    Friend WithEvents Prefetch As Timer
    Friend WithEvents FlatLabel15 As FlatLabel
    Friend WithEvents FlatLabel41 As FlatLabel
    Friend WithEvents FlatLabel40 As FlatLabel
    Friend WithEvents FlatLabel39 As FlatLabel
    Friend WithEvents FlatLabel38 As FlatLabel
    Friend WithEvents FlatLabel37 As FlatLabel
    Friend WithEvents FlatLabel36 As FlatLabel
    Friend WithEvents FlatLabel35 As FlatLabel
End Class
