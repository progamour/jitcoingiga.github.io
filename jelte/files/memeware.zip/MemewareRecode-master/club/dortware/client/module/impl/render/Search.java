package club.dortware.client.module.impl.render;

import club.dortware.client.module.Module;
import net.minecraft.block.Block;

import java.util.List;

public class Search extends Module {
    public List<Block> searchList;

    @Override
    public void setup() {

    }
}
