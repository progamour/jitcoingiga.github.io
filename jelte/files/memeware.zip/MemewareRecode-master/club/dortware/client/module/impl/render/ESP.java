package club.dortware.client.module.impl.render;

import club.dortware.client.module.Module;
import club.dortware.client.module.annotations.ModuleData;
import club.dortware.client.module.enums.ModuleCategory;

@ModuleData(name = "ESP", category = ModuleCategory.RENDER)
public class ESP extends Module {

}