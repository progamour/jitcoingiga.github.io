package club.dortware.client.event.impl;

import club.dortware.client.event.Event;

public class RenderHudEvent extends Event {

}
