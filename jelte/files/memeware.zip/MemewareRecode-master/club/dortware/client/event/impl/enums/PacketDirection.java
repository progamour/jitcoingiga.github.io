package club.dortware.client.event.impl.enums;

public enum PacketDirection {
    INBOUND, OUTBOUND;
}
