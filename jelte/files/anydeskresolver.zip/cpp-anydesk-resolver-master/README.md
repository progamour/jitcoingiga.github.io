# cpp-anydesk-resolver
Generic anydesk resolver using a rather unique method that I have not seen anyone use yet so I decided to release it.

credits to eternity for helping me with stuff (https://github.com/EternalRift)

military grade encryption btw
