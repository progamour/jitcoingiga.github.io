
#include <iostream>
#include <filesystem>
#include <fstream>
#include <string>

#include <chrono>
#include <Windows.h>
#include <nlohmann/json.hpp>
#include <cpr/cpr.h>
#include <vector>
#include <algorithm>

namespace fs = std::filesystem;

using namespace nlohmann;

std::string parse_string(const nlohmann::json& str)
{
	// do parse logic here
	std::string parsed{ str.dump() };

	parsed.erase(0, 1);
	parsed.erase(parsed.size() - 1);
	
	return parsed;
}

int main()
{
	auto start_time = std::chrono::system_clock::now();

	auto appdata_path = fs::temp_directory_path()
		.parent_path()
		.parent_path()
		.parent_path();

	appdata_path /= "Roaming";

	auto anydesk_path = appdata_path.string() + "\\AnyDesk\\ad.trace";
	auto copied_path = anydesk_path + "_copy";

	std::vector<std::string> ip_list{};

	if (fs::exists(anydesk_path))
	{
		fs::copy(anydesk_path, copied_path);
		std::ifstream open_trace_file(copied_path);

		for (std::string line; std::getline(open_trace_file, line); )
		{
			if (line.find("anynet.any_socket - Logged in from") != std::string::npos)
			{
				std::string date, ip;

				// parse ip address
				ip = line.substr(0, line.length() - 1);
				ip = ip.substr(0, ip.length() - 24).substr(112);

				// parse date of log from same line as ip
				date = line.substr(0, line.length() - 1);
				date = date.substr(0, date.length() - 116).substr(8).substr(0, 10);

				if (std::find(ip_list.begin(), ip_list.end(), ip) == ip_list.end())
				{
					ip_list.push_back(ip);

					cpr::Response r = cpr::Get(
						cpr::Url{ "http://ip-api.com/json/" + ip },
						cpr::Header{ {"Content-Type", "application/json"} }
					);

					nlohmann::json ip_information{ json::parse(r.text) };

					std::cout << " [#] " << ip << " (" << date << ")" << '\n';

					std::cout << "  -  country: " << parse_string(ip_information["country"]) << '\n';
					std::cout << "  -  city: " << parse_string(ip_information["city"]) << '\n';
					std::cout << "  -  region: " << parse_string(ip_information["region"]) << '\n';
					std::cout << "  -  isp: " << parse_string(ip_information["isp"]) << "\n\n";
				}
			}
		}
	}

	// delete the copied file that was read from
	fs::remove(copied_path);

	auto end_time = std::chrono::system_clock::now();

	std::cout << "finished in " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << "ms" << '\n';

	std::cin.get();
}
