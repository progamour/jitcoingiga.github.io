﻿namespace EzPing.Core.Shell
{
    using System;

    public enum ShellType
    {
        Commandline,
        Powershell
    }
}

