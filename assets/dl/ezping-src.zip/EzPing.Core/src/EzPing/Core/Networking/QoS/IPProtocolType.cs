﻿namespace EzPing.Core.Networking.QoS
{
    using System;

    public enum IPProtocolType
    {
        TCP,
        UDP,
        Both
    }
}

