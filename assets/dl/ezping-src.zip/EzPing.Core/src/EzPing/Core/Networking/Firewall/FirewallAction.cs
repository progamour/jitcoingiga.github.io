﻿namespace EzPing.Core.Networking.Firewall
{
    using System;

    public enum FirewallAction
    {
        NotConfigured,
        Allow,
        Block
    }
}

