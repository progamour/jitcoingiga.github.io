﻿namespace EzPing.Core.Networking.QoS
{
    using System;

    public enum NetworkProfileType
    {
        Domain,
        Public,
        Private,
        All
    }
}

