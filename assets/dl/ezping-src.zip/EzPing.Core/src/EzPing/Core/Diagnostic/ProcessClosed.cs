﻿namespace EzPing.Core.Diagnostic
{
    using System;
    using System.Diagnostics;
    using System.Runtime.CompilerServices;

    public delegate void ProcessClosed(Process process);
}

